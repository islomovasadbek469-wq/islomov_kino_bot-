from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from bot.config import is_admin


def get_main_menu_keyboard(user_id: int) -> ReplyKeyboardMarkup:
    """Returns the main reply keyboard for the user."""
    keyboard = [
        [
            KeyboardButton(text="🔍 Kino qidirish"),
            KeyboardButton(text="🎲 Tasodifiy kino"),
        ],
        [
            KeyboardButton(text="🔝 Top kinolar"),
            KeyboardButton(text="ℹ️ Bot haqida"),
        ],
    ]

    # Show Admin panel shortcut if user is authorized admin
    if is_admin(user_id):
        keyboard.append([KeyboardButton(text="⚡️ Admin Panel")])

    return ReplyKeyboardMarkup(
        keyboard=keyboard,
        resize_keyboard=True,
        input_field_placeholder="Kino kodini yuboring (masalan: 1)...",
    )


def get_cancel_keyboard() -> ReplyKeyboardMarkup:
    """Cancel button for FSM states."""
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="❌ Bekor qilish")]],
        resize_keyboard=True,
    )
