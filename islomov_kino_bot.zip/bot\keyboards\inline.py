from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from typing import List, Dict, Any, Optional


def get_subscription_keyboard(
    channels: List[Dict[str, Any]], target_code: Optional[str] = None
) -> InlineKeyboardMarkup:
    """Creates inline keyboard with channel links and subscription check button."""
    keyboard = []
    for idx, ch in enumerate(channels, 1):
        keyboard.append(
            [
                InlineKeyboardButton(
                    text=f"📢 {ch['title']}",
                    url=ch["invite_link"],
                )
            ]
        )

    # Verification button
    callback_data = f"check_sub:{target_code}" if target_code else "check_sub:"
    keyboard.append(
        [
            InlineKeyboardButton(
                text="✅ Obunani tekshirish",
                callback_data=callback_data,
            )
        ]
    )

    return InlineKeyboardMarkup(inline_keyboard=keyboard)


def get_admin_keyboard() -> InlineKeyboardMarkup:
    """Main administrative inline panel."""
    keyboard = [
        [
            InlineKeyboardButton(text="➕ Kino qo'shish", callback_data="admin:add_movie"),
            InlineKeyboardButton(text="🗑 Kino o'chirish", callback_data="admin:delete_movie"),
        ],
        [
            InlineKeyboardButton(text="📊 Statistika", callback_data="admin:stats"),
            InlineKeyboardButton(text="📢 Xabar yuborish", callback_data="admin:broadcast"),
        ],
        [
            InlineKeyboardButton(text="🔗 Homiy kanallar", callback_data="admin:channels"),
        ],
    ]
    return InlineKeyboardMarkup(inline_keyboard=keyboard)


def get_channels_management_keyboard(channels: List[Dict[str, Any]]) -> InlineKeyboardMarkup:
    """Keyboard to manage mandatory channels."""
    keyboard = []
    for ch in channels:
        keyboard.append(
            [
                InlineKeyboardButton(text=f"❌ {ch['title']}", callback_data=f"admin:del_channel:{ch['channel_id']}"),
            ]
        )

    keyboard.append(
        [
            InlineKeyboardButton(text="➕ Yangi kanal qo'shish", callback_data="admin:add_channel"),
        ]
    )
    keyboard.append(
        [
            InlineKeyboardButton(text="🔙 Bosh menyu", callback_data="admin:back_to_menu"),
        ]
    )
    return InlineKeyboardMarkup(inline_keyboard=keyboard)


def get_movie_share_keyboard(code: str, bot_username: str) -> InlineKeyboardMarkup:
    """Share button for a movie."""
    share_url = f"https://t.me/share/url?url=https://t.me/{bot_username}?start={code}&text=🎬+Ushbu+kinoni+tomosha+qiling!+Kodi:+{code}"
    keyboard = [
        [
            InlineKeyboardButton(text="↗️ Do'stlarga ulashish", url=share_url)
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=keyboard)
