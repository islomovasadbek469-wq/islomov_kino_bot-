import os
from pathlib import Path
from dotenv import load_dotenv

# Base directory of the project
BASE_DIR = Path(__file__).resolve().parent.parent

# Load .env file
load_dotenv(BASE_DIR / ".env")

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()

# Parse admin IDs from comma-separated string
_admins_str = os.getenv("ADMINS", "").strip()
ADMIN_IDS = set()
if _admins_str:
    for item in _admins_str.split(","):
        cleaned = item.strip()
        if cleaned.isdigit():
            ADMIN_IDS.add(int(cleaned))

# Parse channels from comma-separated string in .env
_channels_str = os.getenv("CHANNELS", "").strip()
CONFIG_CHANNELS = []
if _channels_str:
    for item in _channels_str.split(","):
        cleaned = item.strip()
        if cleaned:
            CONFIG_CHANNELS.append(cleaned)

DB_PATH = BASE_DIR / os.getenv("DB_PATH", "data/kino_bot.db")
# Ensure directory exists for database
DB_PATH.parent.mkdir(parents=True, exist_ok=True)


def is_admin(user_id: int) -> bool:
    """Check if given Telegram user_id is in ADMIN_IDS."""
    return user_id in ADMIN_IDS

