from aiogram import Router, F, Bot
from aiogram.types import CallbackQuery
from bot.subscription_checker import check_user_subscriptions
from bot.database import db
from bot.keyboards.reply import get_main_menu_keyboard
from bot.keyboards.inline import get_movie_share_keyboard

router = Router()


@router.callback_query(F.data.startswith("check_sub:"))
async def handle_sub_check(callback: CallbackQuery, bot: Bot):
    user_id = callback.from_user.id
    target_code = callback.data.split("check_sub:")[1].strip()

    is_subscribed, unsubscribed = await check_user_subscriptions(bot, user_id)

    if not is_subscribed:
        await callback.answer(
            "❌ Hali barcha kanallarga obuna bo'lmadingiz. Iltimos, barcha kanallarga obuna bo'lib qaytadan urinib ko'ring.",
            show_alert=True,
        )
        return

    await callback.answer("✅ Obuna tasdiqlandi!", show_alert=False)

    try:
        await callback.message.delete()
    except Exception:
        pass

    bot_info = await bot.get_me()

    if target_code:
        movie = await db.get_movie_by_code(target_code)
        if movie:
            await db.increment_views(target_code)
            caption = (
                f"🎬 <b>{movie['title']}</b>\n"
                f"🔢 <b>Kino kodi:</b> <code>{movie['code']}</code>\n"
                f"👁 <b>Ko'rishlar soni:</b> {movie['views'] + 1}\n\n"
            )
            if movie.get("description"):
                caption += f"📝 <b>Tavsif:</b>\n{movie['description']}\n\n"

            caption += f"🤖 <b>Botimiz:</b> @{bot_info.username}"

            share_kb = get_movie_share_keyboard(movie["code"], bot_info.username)

            if movie.get("file_type") == "document":
                await bot.send_document(
                    chat_id=user_id,
                    document=movie["file_id"],
                    caption=caption,
                    parse_mode="HTML",
                    reply_markup=share_kb,
                )
            else:
                await bot.send_video(
                    chat_id=user_id,
                    video=movie["file_id"],
                    caption=caption,
                    parse_mode="HTML",
                    reply_markup=share_kb,
                )
            return

    await bot.send_message(
        chat_id=user_id,
        text=(
            "🎉 <b>Xush kelibsiz!</b>\n\n"
            "Kino kodini yuboring yoki quyidagi menyudan kerakli bo'limni tanlang:"
        ),
        parse_mode="HTML",
        reply_markup=get_main_menu_keyboard(user_id),
    )
