import logging
from typing import Tuple, List, Dict, Any
from aiogram import Bot
from aiogram.enums import ChatMemberStatus
from aiogram.exceptions import TelegramBadRequest
from bot.database import db

logger = logging.getLogger(__name__)


def parse_chat_id(channel_id: str):
    """Returns integer chat_id if numeric, else string username."""
    clean = channel_id.strip()
    if (clean.startswith("-") and clean[1:].isdigit()) or clean.isdigit():
        return int(clean)
    return clean


async def check_user_subscriptions(
    bot: Bot, user_id: int
) -> Tuple[bool, List[Dict[str, Any]]]:
    """
    Checks if user is subscribed to all mandatory channels.
    Returns (is_subscribed, list_of_unsubscribed_channels).
    """
    channels = await db.get_all_channels()
    if not channels:
        return True, []

    unsubscribed = []
    for channel in channels:
        raw_id = channel["channel_id"]
        chat_ref = parse_chat_id(raw_id)
        try:
            member = await bot.get_chat_member(chat_id=chat_ref, user_id=user_id)
            if member.status in [ChatMemberStatus.LEFT, ChatMemberStatus.KICKED]:
                unsubscribed.append(channel)
        except TelegramBadRequest as e:
            err_msg = str(e).lower()
            if any(k in err_msg for k in ["user not found", "user_not_participant", "participant_id_invalid"]):
                unsubscribed.append(channel)
            else:
                logger.warning(
                    f"TelegramBadRequest checking channel {raw_id}: {e}. Ensure bot is admin in the channel."
                )
        except Exception as e:
            logger.warning(
                f"Error checking chat member for channel {raw_id}: {e}. Ensure bot is admin in the channel."
            )

    is_subscribed = len(unsubscribed) == 0
    return is_subscribed, unsubscribed
