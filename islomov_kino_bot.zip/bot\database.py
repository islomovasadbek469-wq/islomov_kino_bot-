import aiosqlite
from typing import Optional, List, Dict, Any
from bot.config import DB_PATH


class Database:
    def __init__(self, db_path=DB_PATH):
        self.db_path = db_path

    async def init_db(self):
        """Initialize database tables."""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    full_name TEXT,
                    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS movies (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    code TEXT UNIQUE NOT NULL,
                    title TEXT NOT NULL,
                    description TEXT,
                    file_id TEXT NOT NULL,
                    file_type TEXT DEFAULT 'video',
                    views INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS channels (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    channel_id TEXT UNIQUE NOT NULL,
                    title TEXT NOT NULL,
                    invite_link TEXT NOT NULL
                )
                """
            )
            await db.commit()

    # --- Users Management ---
    async def add_user(self, user_id: int, username: Optional[str], full_name: Optional[str]):
        """Insert or update user in database."""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                """
                INSERT INTO users (user_id, username, full_name)
                VALUES (?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    username=excluded.username,
                    full_name=excluded.full_name
                """,
                (user_id, username, full_name),
            )
            await db.commit()

    async def get_user_count(self) -> int:
        """Get total number of registered users."""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT COUNT(*) FROM users") as cursor:
                row = await cursor.fetchone()
                return row[0] if row else 0

    async def get_all_user_ids(self) -> List[int]:
        """Fetch all user IDs for broadcasting."""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT user_id FROM users") as cursor:
                rows = await cursor.fetchall()
                return [row[0] for row in rows]

    # --- Movies Management ---
    async def add_movie(
        self,
        code: str,
        title: str,
        file_id: str,
        file_type: str = "video",
        description: Optional[str] = None,
    ) -> bool:
        """Add a new movie to database."""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute(
                    """
                    INSERT INTO movies (code, title, description, file_id, file_type)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (code.strip(), title.strip(), description, file_id, file_type),
                )
                await db.commit()
                return True
        except aiosqlite.IntegrityError:
            return False

    async def get_movie_by_code(self, code: str) -> Optional[Dict[str, Any]]:
        """Fetch movie details by its unique code."""
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM movies WHERE code = ?", (code.strip(),)
            ) as cursor:
                row = await cursor.fetchone()
                if row:
                    return dict(row)
                return None

    async def increment_views(self, code: str):
        """Increment movie view count."""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "UPDATE movies SET views = views + 1 WHERE code = ?",
                (code.strip(),),
            )
            await db.commit()

    async def delete_movie(self, code: str) -> bool:
        """Delete a movie by code."""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "DELETE FROM movies WHERE code = ?", (code.strip(),)
            )
            await db.commit()
            return cursor.rowcount > 0

    async def search_movies(self, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Search movies by title or description."""
        search_pattern = f"%{query.strip()}%"
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                """
                SELECT code, title, views FROM movies
                WHERE title LIKE ? OR description LIKE ?
                ORDER BY views DESC LIMIT ?
                """,
                (search_pattern, search_pattern, limit),
            ) as cursor:
                rows = await cursor.fetchall()
                return [dict(r) for r in rows]

    async def get_random_movie(self) -> Optional[Dict[str, Any]]:
        """Fetch a random movie."""
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM movies ORDER BY RANDOM() LIMIT 1"
            ) as cursor:
                row = await cursor.fetchone()
                return dict(row) if row else None

    async def get_top_movies(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Fetch top viewed movies."""
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT code, title, views FROM movies ORDER BY views DESC LIMIT ?",
                (limit,),
            ) as cursor:
                rows = await cursor.fetchall()
                return [dict(r) for r in rows]

    async def get_movie_count(self) -> int:
        """Total number of movies."""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT COUNT(*) FROM movies") as cursor:
                row = await cursor.fetchone()
                return row[0] if row else 0

    async def get_total_views(self) -> int:
        """Total views across all movies."""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT COALESCE(SUM(views), 0) FROM movies") as cursor:
                row = await cursor.fetchone()
                return row[0] if row else 0

    async def get_next_suggested_code(self) -> str:
        """Suggest next numeric code (e.g. 1, 2, 3...)."""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                "SELECT MAX(CAST(code AS INTEGER)) FROM movies WHERE code GLOB '[0-9]*'"
            ) as cursor:
                row = await cursor.fetchone()
                if row and row[0] is not None:
                    return str(row[0] + 1)
                return "1"

    # --- Channels Management ---
    async def add_channel(self, channel_id: str, title: str, invite_link: str) -> bool:
        """Add sponsor channel for mandatory subscription."""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute(
                    """
                    INSERT INTO channels (channel_id, title, invite_link)
                    VALUES (?, ?, ?)
                    ON CONFLICT(channel_id) DO UPDATE SET
                        title=excluded.title,
                        invite_link=excluded.invite_link
                    """,
                    (channel_id.strip(), title.strip(), invite_link.strip()),
                )
                await db.commit()
                return True
        except Exception:
            return False

    async def remove_channel(self, channel_id: str) -> bool:
        """Remove a channel from mandatory subscriptions."""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "DELETE FROM channels WHERE channel_id = ?", (channel_id.strip(),)
            )
            await db.commit()
            return cursor.rowcount > 0

    async def get_all_channels(self) -> List[Dict[str, Any]]:
        """Get all required channels."""
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("SELECT * FROM channels") as cursor:
                rows = await cursor.fetchall()
                return [dict(r) for r in rows]


db = Database()
