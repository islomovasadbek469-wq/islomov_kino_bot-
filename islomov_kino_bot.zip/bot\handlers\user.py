from aiogram import Router, F, Bot
from aiogram.types import Message
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from bot.database import db
from bot.subscription_checker import check_user_subscriptions
from bot.keyboards.reply import get_main_menu_keyboard, get_cancel_keyboard
from bot.keyboards.inline import get_subscription_keyboard, get_movie_share_keyboard, get_admin_keyboard
from bot.config import is_admin

router = Router()


class UserStates(StatesGroup):
    waiting_for_search_query = State()


async def send_movie_to_user(bot: Bot, chat_id: int, movie: dict):
    """Helper function to send a movie to the user."""
    await db.increment_views(movie["code"])
    bot_info = await bot.get_me()

    caption = (
        f"🎬 <b>{movie['title']}</b>\n"
        f"🔢 <b>Kino kodi:</b> <code>{movie['code']}</code>\n"
        f"👁 <b>Ko'rishlar soni:</b> {movie['views'] + 1}\n\n"
    )
    if movie.get("description"):
        caption += f"📝 <b>Tavsif:</b>\n{movie['description']}\n\n"

    caption += f"🤖 <b>Bot:</b> @{bot_info.username}"

    share_kb = get_movie_share_keyboard(movie["code"], bot_info.username)

    if movie.get("file_type") == "document":
        await bot.send_document(
            chat_id=chat_id,
            document=movie["file_id"],
            caption=caption,
            parse_mode="HTML",
            reply_markup=share_kb,
        )
    else:
        await bot.send_video(
            chat_id=chat_id,
            video=movie["file_id"],
            caption=caption,
            parse_mode="HTML",
            reply_markup=share_kb,
        )


@router.message(CommandStart())
async def handle_start(message: Message, bot: Bot, command: CommandStart, state: FSMContext):
    await state.clear()
    user = message.from_user
    await db.add_user(user.id, user.username, user.full_name)

    target_code = command.args.strip() if command.args else None

    # Check subscriptions
    is_subscribed, unsubscribed = await check_user_subscriptions(bot, user.id)
    if not is_subscribed:
        kb = get_subscription_keyboard(unsubscribed, target_code=target_code)
        await message.answer(
            "⚠️ <b>Botdan to'liq foydalanish uchun quyidagi kanallarga obuna bo'ling:</b>\n\n"
            "Kanallarga a'zo bo'lgach, <b>«✅ Obunani tekshirish»</b> tugmasini bosing.",
            reply_markup=kb,
            parse_mode="HTML",
        )
        return

    # If deep-linked with code
    if target_code:
        movie = await db.get_movie_by_code(target_code)
        if movie:
            await send_movie_to_user(bot, message.chat.id, movie)
            return
        else:
            await message.answer(f"❌ <b>{target_code}</b> kodli kino topilmadi.")

    await message.answer(
        f"👋 Assalomu alaykum, <b>{user.first_name}</b>!\n\n"
        f"🎬 <b>@Islomovkinobot</b> ga xush kelibsiz!\n\n"
        f"📥 Kino ko'rish uchun uning <b>kodini yuboring</b> (masalan: <code>1</code>)\n"
        f"yoki quyidagi tugmalardan foydalaning:",
        reply_markup=get_main_menu_keyboard(user.id),
        parse_mode="HTML",
    )


@router.message(F.text == "❌ Bekor qilish")
async def cancel_handler(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "Bekor qilindi.",
        reply_markup=get_main_menu_keyboard(message.from_user.id),
    )


@router.message(F.text == "🔍 Kino qidirish")
async def search_movie_prompt(message: Message, state: FSMContext, bot: Bot):
    is_subscribed, unsubscribed = await check_user_subscriptions(bot, message.from_user.id)
    if not is_subscribed:
        await message.answer(
            "⚠️ Botdan foydalanish uchun homiy kanallarga obuna bo'ling!",
            reply_markup=get_subscription_keyboard(unsubscribed),
        )
        return

    await state.set_state(UserStates.waiting_for_search_query)
    await message.answer(
        "🔍 Qidirayotgan kinongiz nomini kiriting:",
        reply_markup=get_cancel_keyboard(),
    )


@router.message(UserStates.waiting_for_search_query)
async def process_search_query(message: Message, state: FSMContext):
    query = message.text.strip()
    results = await db.search_movies(query, limit=10)
    await state.clear()

    if not results:
        await message.answer(
            f"😔 <b>«{query}»</b> bo'yicha hech qanday kino topilmadi.\n"
            "Kino kodini yuborib ko'ring yoki boshqa nom bilan qidiring.",
            reply_markup=get_main_menu_keyboard(message.from_user.id),
            parse_mode="HTML",
        )
        return

    text = f"🔎 <b>«{query}» bo'yicha topilgan kinolar:</b>\n\n"
    for r in results:
        text += f"🔹 <b>{r['title']}</b> — Kodi: <code>{r['code']}</code> (👁 {r['views']})\n"

    text += "\n💡 Kinoni yuklash uchun uning <b>kodini</b> yuboring!"

    await message.answer(
        text,
        reply_markup=get_main_menu_keyboard(message.from_user.id),
        parse_mode="HTML",
    )


@router.message(F.text == "🎲 Tasodifiy kino")
async def random_movie_handler(message: Message, bot: Bot):
    is_subscribed, unsubscribed = await check_user_subscriptions(bot, message.from_user.id)
    if not is_subscribed:
        await message.answer(
            "⚠️ Botdan foydalanish uchun homiy kanallarga obuna bo'ling!",
            reply_markup=get_subscription_keyboard(unsubscribed),
        )
        return

    movie = await db.get_random_movie()
    if not movie:
        await message.answer("Bazaga hali kinolar qo'shilmagan.")
        return

    await send_movie_to_user(bot, message.chat.id, movie)


@router.message(F.text == "🔝 Top kinolar")
async def top_movies_handler(message: Message, bot: Bot):
    is_subscribed, unsubscribed = await check_user_subscriptions(bot, message.from_user.id)
    if not is_subscribed:
        await message.answer(
            "⚠️ Botdan foydalanish uchun homiy kanallarga obuna bo'ling!",
            reply_markup=get_subscription_keyboard(unsubscribed),
        )
        return

    top_list = await db.get_top_movies(limit=10)
    if not top_list:
        await message.answer("Hozircha kinolar mavjud emas.")
        return

    text = "🔥 <b>Eng ko'p ko'rilgan TOP kinolar:</b>\n\n"
    for idx, m in enumerate(top_list, 1):
        text += f"{idx}. <b>{m['title']}</b>\n   🔢 Kod: <code>{m['code']}</code> | 👁 {m['views']} marta\n\n"

    text += "💡 Kinoni ko'rish uchun uning <b>kodini yozib yuboring</b>."
    await message.answer(text, parse_mode="HTML")


@router.message(F.text == "ℹ️ Bot haqida")
async def about_bot_handler(message: Message):
    total_movies = await db.get_movie_count()
    text = (
        "ℹ️ <b>@Islomovkinobot haqida ma'lumot:</b>\n\n"
        "Bu bot orqali siz turli filmlar, seriallar va multfilmlarni maxsus kod orqali tez va qulay yuklab olishingiz mumkin.\n\n"
        f"📊 <b>Botdagi kinolar soni:</b> {total_movies} ta\n\n"
        "❓ <b>Qanday ishlatiladi?</b>\n"
        "1. Ijtimoiy tarmoqlarimizda (TikTok, Instagram, Telegram) e'lon qilingan kino kodini oling.\n"
        "2. Botga o'sha kodni yozib yuboring (masalan: <code>15</code>).\n"
        "3. Bot sizga kinoni yuboradi!\n\n"
        "Murojaat va takliflar uchun admin bilan bog'laning."
    )
    await message.answer(text, parse_mode="HTML")


@router.message(F.text == "⚡️ Admin Panel")
async def admin_shortcut_handler(message: Message):
    if not is_admin(message.from_user.id):
        return
    await message.answer(
        "🛠 <b>Boshqaruv paneli:</b>",
        reply_markup=get_admin_keyboard(),
        parse_mode="HTML",
    )


@router.message(F.text)
async def handle_code_input(message: Message, bot: Bot):
    """Handles direct code input from the user."""
    user_id = message.from_user.id
    code_input = message.text.strip()

    # Check subscriptions first
    is_subscribed, unsubscribed = await check_user_subscriptions(bot, user_id)
    if not is_subscribed:
        await message.answer(
            "⚠️ Botdan foydalanish uchun homiy kanallarga obuna bo'ling!",
            reply_markup=get_subscription_keyboard(unsubscribed, target_code=code_input),
        )
        return

    # Check if this matches a movie code
    movie = await db.get_movie_by_code(code_input)
    if movie:
        await send_movie_to_user(bot, message.chat.id, movie)
        return

    # If code not found, try title search as fallback
    search_results = await db.search_movies(code_input, limit=5)
    if search_results:
        text = (
            f"❌ <code>{code_input}</code> kodli kino topilmadi.\n\n"
            f"🔎 Ammo shunga o'xshash kinolar topildi:\n"
        )
        for r in search_results:
            text += f"🔹 <b>{r['title']}</b> — Kod: <code>{r['code']}</code>\n"
        text += "\nKinoni olish uchun uning kodini yuboring."
        await message.answer(text, parse_mode="HTML")
    else:
        await message.answer(
            f"❌ <b>{code_input}</b> kodi bo'yicha kino topilmadi.\n\n"
            "Iltimos, kodni to'g'riligini tekshiring yoki <b>«🔍 Kino qidirish»</b> bo'limidan foydalaning.",
            parse_mode="HTML",
        )
