import asyncio
import logging
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from bot.config import is_admin
from bot.database import db
from bot.keyboards.inline import get_admin_keyboard, get_channels_management_keyboard
from bot.keyboards.reply import get_main_menu_keyboard

logger = logging.getLogger(__name__)
router = Router()


class AdminStates(StatesGroup):
    # Add movie flow
    waiting_for_movie_file = State()
    waiting_for_movie_code = State()
    waiting_for_movie_title = State()
    waiting_for_movie_desc = State()

    # Delete movie flow
    waiting_for_delete_code = State()

    # Broadcast flow
    waiting_for_broadcast_message = State()

    # Channel add flow
    waiting_for_channel_id = State()
    waiting_for_channel_title = State()
    waiting_for_channel_link = State()


# --- Admin Entry Point ---
@router.message(Command("admin"))
async def admin_panel(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    await state.clear()
    await message.answer(
        "🛠 <b>Boshqaruv paneli (Admin Panel):</b>\n\nKerakli bo'limni tanlang:",
        reply_markup=get_admin_keyboard(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "admin:back_to_menu")
async def back_to_admin_menu(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer("Ruxsat berilmagan.", show_alert=True)
        return

    await state.clear()
    await callback.message.edit_text(
        "🛠 <b>Boshqaruv paneli (Admin Panel):</b>\n\nKerakli bo'limni tanlang:",
        reply_markup=get_admin_keyboard(),
        parse_mode="HTML",
    )


# --- Statistics ---
@router.callback_query(F.data == "admin:stats")
async def show_stats(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return

    total_users = await db.get_user_count()
    total_movies = await db.get_movie_count()
    total_views = await db.get_total_views()
    channels = await db.get_all_channels()

    text = (
        "📊 <b>Bot Statistikasi:</b>\n\n"
        f"👥 <b>Foydalanuvchilar:</b> {total_users} ta\n"
        f"🎬 <b>Yuklangan kinolar:</b> {total_movies} ta\n"
        f"👁 <b>Umumiy ko'rishlar:</b> {total_views} marta\n"
        f"📢 <b>Homiy kanallar:</b> {len(channels)} ta\n"
    )
    back_kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="🔙 Orqaga", callback_data="admin:back_to_menu")]]
    )
    await callback.message.edit_text(text, reply_markup=back_kb, parse_mode="HTML")


# --- Add Movie Flow ---
@router.callback_query(F.data == "admin:add_movie")
async def start_add_movie(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return

    await state.set_state(AdminStates.waiting_for_movie_file)
    cancel_kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="admin:back_to_menu")]]
    )
    await callback.message.edit_text(
        "📤 <b>1-qadam:</b> Kinoning video yoki faylini yuboring:",
        reply_markup=cancel_kb,
        parse_mode="HTML",
    )


@router.message(AdminStates.waiting_for_movie_file, F.video | F.document)
async def process_movie_file(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    if message.video:
        file_id = message.video.file_id
        file_type = "video"
    else:
        file_id = message.document.file_id
        file_type = "document"

    await state.update_data(file_id=file_id, file_type=file_type)

    suggested_code = await db.get_next_suggested_code()
    await state.set_state(AdminStates.waiting_for_movie_code)

    cancel_kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="admin:back_to_menu")]]
    )
    await message.answer(
        f"🔢 <b>2-qadam:</b> Kino kodini kiriting.\n\n"
        f"<i>Tavsiya etilgan navbatdagi kod:</i> <code>{suggested_code}</code>",
        reply_markup=cancel_kb,
        parse_mode="HTML",
    )


@router.message(AdminStates.waiting_for_movie_code, F.text)
async def process_movie_code(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    code = message.text.strip()
    existing = await db.get_movie_by_code(code)
    if existing:
        await message.answer(
            f"⚠️ <b>{code}</b> kodi allaqachon mavjud!\n"
            f"Hozirgi kino: «{existing['title']}»\n\n"
            "Iltimos, boshqa kod kiriting:",
            parse_mode="HTML",
        )
        return

    await state.update_data(code=code)
    await state.set_state(AdminStates.waiting_for_movie_title)

    cancel_kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="admin:back_to_menu")]]
    )
    await message.answer(
        "📝 <b>3-qadam:</b> Kino nomini kiriting (masalan: <i>Avatar 2: Suv yo'li (2022)</i>):",
        reply_markup=cancel_kb,
        parse_mode="HTML",
    )


@router.message(AdminStates.waiting_for_movie_title, F.text)
async def process_movie_title(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    title = message.text.strip()
    await state.update_data(title=title)
    await state.set_state(AdminStates.waiting_for_movie_desc)

    skip_kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="⏭ O'tkazib yuborish (Tavsifsiz)", callback_data="admin:skip_desc")],
            [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="admin:back_to_menu")],
        ]
    )
    await message.answer(
        "📄 <b>4-qadam:</b> Kino tavsifini yoki janrini kiriting (yoki quyidagi tugma orqali o'tkazib yuboring):",
        reply_markup=skip_kb,
        parse_mode="HTML",
    )


@router.callback_query(AdminStates.waiting_for_movie_desc, F.data == "admin:skip_desc")
async def process_movie_skip_desc(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    await finish_add_movie(callback.message, data, description=None)
    await state.clear()


@router.message(AdminStates.waiting_for_movie_desc, F.text)
async def process_movie_desc(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    data = await state.get_data()
    desc = message.text.strip()
    await finish_add_movie(message, data, description=desc)
    await state.clear()


async def finish_add_movie(message: Message, data: dict, description: str = None):
    success = await db.add_movie(
        code=data["code"],
        title=data["title"],
        file_id=data["file_id"],
        file_type=data["file_type"],
        description=description,
    )

    if success:
        text = (
            "✅ <b>Kino muvaffaqiyatli saqlandi!</b>\n\n"
            f"🎬 <b>Nomi:</b> {data['title']}\n"
            f"🔢 <b>Kodi:</b> <code>{data['code']}</code>\n"
        )
        if description:
            text += f"📝 <b>Tavsif:</b> {description}\n"
    else:
        text = "❌ Xatolik yuz berdi. Kod band bo'lishi mumkin."

    await message.answer(
        text,
        reply_markup=get_admin_keyboard(),
        parse_mode="HTML",
    )


# --- Delete Movie Flow ---
@router.callback_query(F.data == "admin:delete_movie")
async def start_delete_movie(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return

    await state.set_state(AdminStates.waiting_for_delete_code)
    cancel_kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="admin:back_to_menu")]]
    )
    await callback.message.edit_text(
        "🗑 O'chirmoqchi bo'lgan <b>kino kodini</b> yuboring:",
        reply_markup=cancel_kb,
        parse_mode="HTML",
    )


@router.message(AdminStates.waiting_for_delete_code, F.text)
async def process_delete_code(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    code = message.text.strip()
    movie = await db.get_movie_by_code(code)
    if not movie:
        await message.answer(f"❌ <code>{code}</code> kodli kino topilmadi.")
        return

    deleted = await db.delete_movie(code)
    await state.clear()

    if deleted:
        await message.answer(
            f"✅ <b>{code}</b> kodli («{movie['title']}») kino o'chirildi.",
            reply_markup=get_admin_keyboard(),
            parse_mode="HTML",
        )
    else:
        await message.answer(
            "❌ Kinoni o'chirishda xatolik yuz berdi.",
            reply_markup=get_admin_keyboard(),
        )


# --- Broadcast Flow ---
@router.callback_query(F.data == "admin:broadcast")
async def start_broadcast(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return

    await state.set_state(AdminStates.waiting_for_broadcast_message)
    cancel_kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="admin:back_to_menu")]]
    )
    await callback.message.edit_text(
        "📢 Barcha foydalanuvchilarga yubormoqchi bo'lgan xabaringizni yuboring (matn, rasm yoki video):",
        reply_markup=cancel_kb,
    )


@router.message(AdminStates.waiting_for_broadcast_message)
async def process_broadcast_message(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return

    await state.clear()
    users = await db.get_all_user_ids()
    total = len(users)

    if total == 0:
        await message.answer("Foydalanuvchilar mavjud emas.", reply_markup=get_admin_keyboard())
        return

    status_msg = await message.answer(f"⏳ Xabar tarqatilmoqda (0/{total})...")

    sent = 0
    failed = 0

    for idx, user_id in enumerate(users, 1):
        try:
            await message.copy_to(chat_id=user_id)
            sent += 1
        except Exception:
            failed += 1

        # Periodic update every 25 users
        if idx % 25 == 0:
            try:
                await status_msg.edit_text(f"⏳ Xabar tarqatilmoqda ({idx}/{total})...\nYetkazildi: {sent} | Xatolik: {failed}")
            except Exception:
                pass
        await asyncio.sleep(0.05)  # Respect Telegram rate limits

    try:
        await status_msg.delete()
    except Exception:
        pass

    await message.answer(
        f"✅ <b>Xabar tarqatish yakunlandi!</b>\n\n"
        f"👥 Jami foydalanuvchilar: {total}\n"
        f"🟢 Yetkazildi: {sent}\n"
        f"🔴 Yetkazilmadi (bloklagan): {failed}",
        reply_markup=get_admin_keyboard(),
        parse_mode="HTML",
    )


# --- Mandatory Channels Management Flow ---
@router.callback_query(F.data == "admin:channels")
async def show_channels_management(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return

    channels = await db.get_all_channels()
    text = "🔗 <b>Homiy kanallar ro'yxati:</b>\n\n"
    if channels:
        for idx, ch in enumerate(channels, 1):
            text += f"{idx}. <b>{ch['title']}</b> ({ch['channel_id']})\n   🔗 {ch['invite_link']}\n"
        text += "\nKanalni o'chirish uchun quyidagi tugmalardan birini bosing:"
    else:
        text += "Hozircha hech qanday homiy kanal belgilanmagan."

    await callback.message.edit_text(
        text,
        reply_markup=get_channels_management_keyboard(channels),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("admin:del_channel:"))
async def delete_channel(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return

    channel_id = callback.data.split("admin:del_channel:")[1]
    await db.remove_channel(channel_id)
    await callback.answer("Kanal o'chirildi!", show_alert=True)
    await show_channels_management(callback)


@router.callback_query(F.data == "admin:add_channel")
async def start_add_channel(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return

    await state.set_state(AdminStates.waiting_for_channel_id)
    cancel_kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="admin:channels")]]
    )
    await callback.message.edit_text(
        "📢 <b>Kanal qo'shish:</b>\n\n"
        "1. Avval botni (@Islomovkinobot) kanalingizga <b>ADMIN</b> qilib qo'shing.\n"
        "2. So'ngra kanaldan biror <b>postni bu yerga forward (uzating)</b> yoki kanal username/havolasini yuboring (masalan: <code>@mening_kanalim</code>):\n\n"
        "<i>Bot avtomatik ravishda kanal nomi va havolasini aniqlaydi!</i>",
        reply_markup=cancel_kb,
        parse_mode="HTML",
    )


@router.message(AdminStates.waiting_for_channel_id)
async def process_channel_id(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return

    raw_input = ""
    # Check if forwarded from channel
    if message.forward_origin and hasattr(message.forward_origin, "chat"):
        raw_input = str(message.forward_origin.chat.id)
    elif message.forward_from_chat:
        raw_input = str(message.forward_from_chat.id)
    elif message.text:
        text = message.text.strip()
        # Clean URL if user pasted https://t.me/channel
        if "t.me/" in text:
            parts = text.split("t.me/")[-1].replace("+", "").replace("/", "").strip()
            raw_input = f"@{parts}" if not parts.startswith("@") else parts
        else:
            raw_input = text

    if not raw_input:
        await message.answer("Iltimos, kanal username'ini yuboring yoki kanaldan post uzating.")
        return

    # Try to resolve chat reference
    chat_ref = int(raw_input) if (raw_input.startswith("-") and raw_input[1:].isdigit()) or raw_input.isdigit() else raw_input

    try:
        chat = await bot.get_chat(chat_ref)
        bot_user = await bot.get_me()
        member = await bot.get_chat_member(chat.id, bot_user.id)

        if member.status not in ["administrator", "creator"]:
            await message.answer(
                "⚠️ <b>Bot ushbu kanalda administrator emas!</b>\n\n"
                f"Kanal: <b>{chat.title}</b>\n"
                f"Iltimos, avval @{bot_user.username} ni ushbu kanalga <b>Admin</b> qilib qo'shing va so'ngra qaytadan yuboring.",
                parse_mode="HTML",
            )
            return

        # Bot is admin! Determine link
        channel_title = chat.title
        channel_id = str(chat.id)
        if chat.username:
            invite_link = f"https://t.me/{chat.username}"
        elif chat.invite_link:
            invite_link = chat.invite_link
        else:
            try:
                created_link = await bot.create_chat_invite_link(chat.id)
                invite_link = created_link.invite_link
            except Exception:
                invite_link = f"https://t.me/{raw_input.lstrip('@')}"

        await db.add_channel(
            channel_id=channel_id,
            title=channel_title,
            invite_link=invite_link,
        )
        await state.clear()

        await message.answer(
            f"✅ <b>Kanal muvaffaqiyatli qo'shildi!</b>\n\n"
            f"📢 <b>Nomi:</b> {channel_title}\n"
            f"🆔 <b>ID:</b> <code>{channel_id}</code>\n"
            f"🔗 <b>Havola:</b> {invite_link}\n\n"
            "Endi barcha foydalanuvchilar kinolarni ko'rishdan oldin ushbu kanalga obuna bo'lishlari shart bo'ladi.",
            reply_markup=get_admin_keyboard(),
            parse_mode="HTML",
        )
        return

    except Exception as e:
        logger.warning(f"Could not auto-fetch channel '{raw_input}': {e}")
        # Fallback to manual entry
        await state.update_data(channel_id=str(chat_ref))
        await state.set_state(AdminStates.waiting_for_channel_title)
        cancel_kb = InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="admin:channels")]]
        )
        await message.answer(
            f"ℹ️ Kanal avtomatik aniqlanmadi (yoki yopiq kanal).\n\n"
            "📝 <b>2-qadam:</b> Kanal nomini qo'lda kiriting (masalan: <i>Premyera Kinolar</i>):",
            reply_markup=cancel_kb,
            parse_mode="HTML",
        )


@router.message(AdminStates.waiting_for_channel_title, F.text)
async def process_channel_title(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    title = message.text.strip()
    await state.update_data(channel_title=title)
    await state.set_state(AdminStates.waiting_for_channel_link)

    cancel_kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="admin:channels")]]
    )
    await message.answer(
        "🔗 <b>3-qadam:</b> Kanalga kirish taklif havolasini (link) yuboring (masalan: <code>https://t.me/...</code>):",
        reply_markup=cancel_kb,
        parse_mode="HTML",
    )


@router.message(AdminStates.waiting_for_channel_link, F.text)
async def process_channel_link(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    link = message.text.strip()
    data = await state.get_data()
    await state.clear()

    await db.add_channel(
        channel_id=data["channel_id"],
        title=data["channel_title"],
        invite_link=link,
    )

    await message.answer(
        f"✅ <b>Kanal muvaffaqiyatli qo'shildi!</b>\n\n"
        f"📢 Nomi: {data['channel_title']}\n"
        f"🆔 ID: {data['channel_id']}\n"
        f"🔗 Havola: {link}",
        reply_markup=get_admin_keyboard(),
        parse_mode="HTML",
    )

